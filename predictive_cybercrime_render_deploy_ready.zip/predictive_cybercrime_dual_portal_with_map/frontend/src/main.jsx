import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, CircleMarker, Popup, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { createRoot } from 'react-dom/client';
import './style.css';

function readSavedUser() {
  try {
    return JSON.parse(localStorage.getItem('user') || 'null');
  } catch {
    localStorage.removeItem('user');
    return null;
  }
}

function App() {
  const [token, setToken] = useState(localStorage.getItem('token') || '');
  const [user, setUser] = useState(readSavedUser);
  const [role, setRole] = useState('public');
  const [register, setRegister] = useState(false);
  const [page, setPage] = useState('Overview');
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [dashboard, setDashboard] = useState(null);
  const [busy, setBusy] = useState(false);

  async function api(path, options = {}, authToken = token) {
    const response = await fetch('/api' + path, {
      ...options,
      headers: {
        ...(options.body ? { 'Content-Type': 'application/json' } : {}),
        ...(authToken ? { Authorization: `Bearer ${authToken}` } : {}),
        ...(options.headers || {})
      }
    });

    const text = await response.text();
    let result = {};
    if (text) {
      try {
        result = JSON.parse(text);
      } catch {
        throw new Error(`Server returned a non-JSON response (${response.status}). Check the Flask terminal.`);
      }
    }

    if (!response.ok) {
      throw new Error(result.error || `Request failed (${response.status})`);
    }
    return result;
  }

  function clearSession() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setToken('');
    setUser(null);
    setDashboard(null);
    setPage('Overview');
  }

  async function handleLogin(event) {
    event.preventDefault();
    setError('');
    setNotice('');
    setBusy(true);
    const form = new FormData(event.currentTarget);

    try {
      const result = await api(register ? '/register' : '/login', {
        method: 'POST',
        body: JSON.stringify({
          name: form.get('name'),
          email: form.get('email'),
          password: form.get('password'),
          role
        })
      }, '');

      if (!result.token || !result.user) {
        throw new Error('Login response did not contain a token and user account.');
      }

      localStorage.setItem('token', result.token);
      localStorage.setItem('user', JSON.stringify(result.user));
      setToken(result.token);
      setUser(result.user);
      setPage('Overview');
      setNotice('Login successful.');
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  async function loadDashboard(currentToken = token, currentUser = user) {
    if (!currentToken || !currentUser) return;
    try {
      const path = currentUser.role === 'police'
        ? '/police/dashboard'
        : '/public/risk-areas';
      const result = await api(path, {}, currentToken);
      setDashboard(result);
      setError('');
    } catch (err) {
      setError(err.message);
      if (err.message.toLowerCase().includes('login required')) {
        clearSession();
      }
    }
  }

  useEffect(() => {
    if (token && user) loadDashboard(token, user);
    // Load only when the authenticated session changes.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token, user]);

  function logout() {
    clearSession();
    setError('');
    setNotice('You have logged out.');
  }

  if (!token || !user) {
    return (
      <main className="login">
        <form onSubmit={handleLogin} className="login-card">
          <h1>🛡 Predictive Cybercrime Analysis</h1>
          <p>Secure citizen and police portal</p>

          {!register && (
            <div className="roles">
              <button type="button" className={role === 'public' ? 'chosen' : ''}
                onClick={() => setRole('public')}>Public</button>
              <button type="button" className={role === 'police' ? 'chosen' : ''}
                onClick={() => setRole('police')}>Police</button>
            </div>
          )}

          {register && (
            <label>Full name
              <input name="name" required autoComplete="name" />
            </label>
          )}

          <label>Email
            <input name="email" type="email" required autoComplete="username" />
          </label>

          <label>Password
            <input name="password" type="password" minLength="8"
              required autoComplete={register ? 'new-password' : 'current-password'} />
          </label>

          <button className="main" type="submit" disabled={busy}>
            {busy ? 'Please wait...' : register ? 'Create public account' : 'Login'}
          </button>

          {error && <p className="error">{error}</p>}
          {notice && <p className="success">{notice}</p>}

          <p>
            <button type="button" className="link"
              onClick={() => { setRegister(!register); setError(''); }}>
              {register ? 'Back to login' : 'Create public account'}
            </button>
          </p>

          <small>Police accounts must be created by an authorized administrator. Public registration cannot create police access.</small>
        </form>
      </main>
    );
  }

  const menu = user.role === 'public'
    ? ['Overview', 'Raise complaint', 'My complaints', 'Risk areas', 'My Account']
    : ['Overview', 'All complaints', 'Risk analysis', 'My Account'];

  return (
    <div className="layout">
      <aside>
        <h2>🛡 Cybercrime</h2>
        <p>{user.role.toUpperCase()} PORTAL</p>
        {menu.map(item => (
          <button key={item} className={page === item ? 'sel' : ''}
            onClick={() => { setPage(item); setError(''); setNotice(''); }}>
            {item}
          </button>
        ))}
        <button onClick={logout}>Logout</button>
      </aside>

      <main className="mainview">
        <header>
          <span>{page}</span>
          <span>{user.name || user.email}</span>
        </header>

        {error && <p className="error">{error}</p>}
        {notice && <p className="success">{notice}</p>}

        {page === 'Overview' && (
          <>
            <h1>{user.role === 'police' ? 'Police intelligence dashboard' : 'Welcome to citizen services'}</h1>
            {user.role === 'public'
              ? <p>Submit a complaint, track your reports and view generalized risk areas.</p>
              : <>
                  <Stats metrics={dashboard?.metrics || {}} />
                  <PolicePredictionMap api={api} onError={setError} />
                </>}
          </>
        )}

        {page === 'Raise complaint' && (
          <Complaint api={api} onSuccess={(reference) => {
            setNotice(`Complaint submitted successfully. Reference: CC-${reference}`);
            setPage('My complaints');
          }} onError={setError} />
        )}

        {page === 'My complaints' && <MyComplaints api={api} onError={setError} />}
        {page === 'Risk areas' && <PublicRisk api={api} onError={setError} />}
        {page === 'Risk analysis' && <>
          <PolicePredictionMap api={api} onError={setError} />
          <Areas rows={dashboard?.risk_areas || []} police />
        </>}
        {page === 'All complaints' && <PoliceCases api={api} onError={setError} />}
        {page === 'My Account' && <Account user={user} />}
      </main>
    </div>
  );
}


function MapResize() {
  const map = useMap();
  useEffect(() => {
    const timer = setTimeout(() => map.invalidateSize(), 150);
    return () => clearTimeout(timer);
  }, [map]);
  return null;
}

function PolicePredictionMap({ api, onError }) {
  const [points, setPoints] = useState([]);
  useEffect(() => {
    api('/police/predictions')
      .then(result => setPoints(result.predictions || []))
      .catch(err => onError(err.message));
  }, []);

  return (
    <section className="box map-box">
      <h2>Predicted cash-out hotspots</h2>
      <p className="hint">
        Broad candidate areas for police review, based on a demo heuristic.
        Markers are locality-level estimates, not a suspect's live location.
      </p>
      <div className="map-frame">
        <MapContainer center={[17.3850, 78.4867]} zoom={11} scrollWheelZoom={true}>
          <MapResize />
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          {points.map(point => (
            <CircleMarker
              key={point.id}
              center={[point.predicted_lat, point.predicted_lng]}
              radius={10}
              pathOptions={{ color: '#b42318', fillColor: '#ef4444', fillOpacity: 0.65 }}
            >
              <Popup>
                <strong>Complaint CC-{point.id}</strong><br />
                {point.predicted_area}<br />
                Category: {point.category}<br />
                Risk score: {point.risk}/100<br />
                Demo confidence: {point.prediction_confidence}%
              </Popup>
            </CircleMarker>
          ))}
        </MapContainer>
      </div>
      {!points.length && <p>No prediction markers yet. Submit a demo complaint to see a marker.</p>}
    </section>
  );
}

function Stats({ metrics }) {
  return (
    <div className="stats">
      {Object.entries(metrics).map(([key, value]) => (
        <article key={key}>
          <small>{key.replaceAll('_', ' ')}</small>
          <h2>{key === 'reported_amount'
            ? '₹' + Number(value).toLocaleString('en-IN')
            : value}</h2>
        </article>
      ))}
    </div>
  );
}

function Account({ user }) {
  return (
    <section className="box">
      <h2>My Account Details</h2>
      <p><strong>Name:</strong> {user.name || 'Not available'}</p>
      <p><strong>Email:</strong> {user.email || 'Not available'}</p>
      <p><strong>Role:</strong> {user.role || 'Not available'}</p>
      {user.badge && <p><strong>Badge ID:</strong> {user.badge}</p>}
      <p><strong>Account type:</strong> {user.role === 'police' ? 'Police Officer' : 'Public User'}</p>
    </section>
  );
}

function Areas({ rows, police = false }) {
  return (
    <section className="box">
      <h2>Area-level risk summary</h2>
      <div className="table-wrap">
        <table>
          <thead><tr>
            <th>City</th><th>Area</th><th>Complaints</th>
            {police && <><th>Risk score</th><th>Reported amount</th></>}
          </tr></thead>
          <tbody>
            {rows.map((item, index) => (
              <tr key={`${item.city}-${item.area}-${index}`}>
                <td>{item.city}</td><td>{item.area}</td><td>{item.complaints}</td>
                {police && <><td>{item.risk_score}/100</td>
                  <td>₹{Number(item.reported_amount).toLocaleString('en-IN')}</td></>}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {!rows.length && <p>No area data available yet.</p>}
    </section>
  );
}

function PublicRisk({ api, onError }) {
  const [rows, setRows] = useState([]);
  useEffect(() => {
    api('/public/risk-areas')
      .then(result => setRows(result.risk_areas || []))
      .catch(err => onError(err.message));
  }, []);
  return <Areas rows={rows} />;
}

function Complaint({ api, onSuccess, onError }) {
  const [busy, setBusy] = useState(false);

  async function submit(event) {
    event.preventDefault();
    onError('');
    setBusy(true);
    const form = event.currentTarget;
    const values = Object.fromEntries(new FormData(form).entries());

    try {
      const result = await api('/complaints', {
        method: 'POST',
        body: JSON.stringify(values)
      });
      form.reset();
      onSuccess(result.complaint_id);
    } catch (err) {
      onError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="box">
      <h2>Raise cybercrime complaint</h2>
      <form onSubmit={submit} className="grid">
        <label>Category
          <select name="category" required>
            <option value="UPI fraud">UPI fraud</option>
            <option value="Bank transfer fraud">Bank transfer fraud</option>
            <option value="Investment scam">Investment scam</option>
            <option value="Phishing">Phishing</option>
            <option value="Identity theft">Identity theft</option>
            <option value="Other">Other</option>
          </select>
        </label>

        <label>Incident date
          <input type="date" name="incident_date" required />
        </label>

        <label>City
          <input name="city" placeholder="Hyderabad" required />
        </label>

        <label>Area
          <input name="area" placeholder="Madhapur" required />
        </label>

        <label>Approximate amount lost (₹)
          <input name="amount" type="number" min="0" step="0.01" defaultValue="0" />
        </label>

        <label className="wide">What happened?
          <textarea name="description" minLength="15" required
            placeholder="Describe what happened. Do not include passwords, PINs or OTPs." />
        </label>

        <button className="main wide" type="submit" disabled={busy}>
          {busy ? 'Submitting...' : 'Submit complaint'}
        </button>
      </form>
      <p className="hint">Never enter passwords, PINs, OTPs or full bank account details in a complaint.</p>
    </section>
  );
}

function MyComplaints({ api, onError }) {
  const [rows, setRows] = useState([]);
  useEffect(() => {
    api('/my-complaints')
      .then(result => setRows(result.complaints || []))
      .catch(err => onError(err.message));
  }, []);

  return (
    <section className="box">
      <h2>My complaints</h2>
      <div className="table-wrap">
        <table>
          <thead><tr><th>Reference</th><th>Category</th><th>Area</th><th>Date</th><th>Status</th></tr></thead>
          <tbody>
            {rows.map(row => (
              <tr key={row.id}>
                <td>CC-{row.id}</td><td>{row.category}</td>
                <td>{row.area}, {row.city}</td><td>{row.incident_date}</td><td>{row.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {!rows.length && <p>No complaints submitted yet.</p>}
    </section>
  );
}

function PoliceCases({ api, onError }) {
  const [rows, setRows] = useState([]);
  const [selected, setSelected] = useState(null);

  async function refresh() {
    try {
      const result = await api('/police/complaints');
      setRows(result.complaints || []);
      if (selected) {
        const updated = (result.complaints || []).find(item => item.id === selected.id);
        setSelected(updated || null);
      }
    } catch (err) {
      onError(err.message);
    }
  }

  useEffect(() => { refresh(); }, []);

  async function changeStatus(id, status) {
    try {
      await api(`/police/complaints/${id}`, {
        method: 'PATCH',
        body: JSON.stringify({ status })
      });
      await refresh();
    } catch (err) {
      onError(err.message);
    }
  }

  return (
    <section className="box">
      <h2>All public complaints</h2>
      <p className="hint">Select “View prediction” on any complaint to inspect that complaint’s individual candidate cash-out area and map.</p>

      {selected && (
        <section className="prediction-detail">
          <div className="detail-heading">
            <h3>Prediction for complaint CC-{selected.id}</h3>
            <button type="button" onClick={() => setSelected(null)}>Close details</button>
          </div>
          <div className="detail-grid">
            <p><strong>Reporter:</strong> {selected.reporter_name}</p>
            <p><strong>Category:</strong> {selected.category}</p>
            <p><strong>Reported location:</strong> {selected.area}, {selected.city}</p>
            <p><strong>Amount reported:</strong> ₹{Number(selected.amount).toLocaleString('en-IN')}</p>
            <p><strong>Candidate area:</strong> {selected.predicted_area || 'Not available'}</p>
            <p><strong>Demo confidence:</strong> {selected.prediction_confidence ?? 'Not available'}%</p>
          </div>
          {selected.predicted_lat != null && selected.predicted_lng != null ? (
            <IndividualPredictionMap complaint={selected} />
          ) : (
            <p className="hint">No prediction coordinates are stored for this complaint.</p>
          )}
          <p className="hint">This is an illustrative locality-level estimate for the project demo. It is not a verified location of a suspect or a live tracking result. Officers must verify leads independently.</p>
        </section>
      )}

      <div className="table-wrap">
        <table>
          <thead><tr>
            <th>Reference</th><th>Reporter</th><th>Complaint</th>
            <th>Reported area</th><th>Candidate cash-out area</th><th>Amount</th><th>Risk</th><th>Status</th><th>Action</th>
          </tr></thead>
          <tbody>
            {rows.map(row => (
              <tr key={row.id}>
                <td>CC-{row.id}</td>
                <td>{row.reporter_name}<br />{row.reporter_email}</td>
                <td>{row.category}<br />{row.description}</td>
                <td>{row.area}, {row.city}</td>
                <td>{row.predicted_area || 'Not available'}<br />
                  <small>Demo confidence: {row.prediction_confidence ?? '—'}%</small></td>
                <td>₹{Number(row.amount).toLocaleString('en-IN')}</td>
                <td>{row.risk}/100</td>
                <td>
                  <select value={row.status}
                    onChange={event => changeStatus(row.id, event.target.value)}>
                    <option>Submitted</option>
                    <option>Under Review</option>
                    <option>Resolved</option>
                    <option>Closed</option>
                  </select>
                </td>
                <td><button type="button" className="view-button" onClick={() => setSelected(row)}>View prediction</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {!rows.length && <p>No complaints have been submitted yet.</p>}
    </section>
  );
}

function IndividualPredictionMap({ complaint }) {
  const center = [Number(complaint.predicted_lat), Number(complaint.predicted_lng)];
  return (
    <div className="map-frame individual-map">
      <MapContainer key={`complaint-${complaint.id}`} center={center} zoom={13} scrollWheelZoom={true}>
        <MapResize />
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        <CircleMarker center={center} radius={13}
          pathOptions={{ color: '#9f1239', fillColor: '#e11d48', fillOpacity: 0.7 }}>
          <Popup>
            <strong>Complaint CC-{complaint.id}</strong><br />
            Candidate area: {complaint.predicted_area}<br />
            Demo confidence: {complaint.prediction_confidence}%
          </Popup>
        </CircleMarker>
      </MapContainer>
    </div>
  );
}

createRoot(document.getElementById('root')).render(<App />);
